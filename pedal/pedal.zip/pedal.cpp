/*
	Pedal.cpp : a library to control the pedal for an electric car
	maps linear pot to rotary pot during calibration, then run checks to see if map fails
	
	rotary pot: clarostat hrs100swab090
	linear pot: ???
	
	Chris Davies, sept 2018
*/

#include "Arduino.h"
#include "pedal.h"

Pedal::Pedal(short rotaryPin, short linearPin){
	analogReadResolution(8);	//set resolution to 1 byte
	rot = rotary;
	lin = linear;
	for(unsigned short i = 0; i < 256; i++) potVal[i] = 0;
}

inline bool Pedal::check(byte rotVal, byte linVal){
	if(potVal[rotVal] < linVal+err && potVal[rotVal] > linVal-err)
		return true;
	return false;
	
}

void Pedal::calibrate(){
	byte currVal;
	while true{		//when to exit loop?
		currVal = analogRead(rot);
		potVal[currVal] = analogRead(lin);
		if(mini > currVal) mini = currVal;
		else if(maxi < currVal) maxi = currVal;
	}
}

byte Pedal::read(){
	byte currVal = analogRead(rot);
	if(check(currVal, analogRead(lin), err)
		return map(currVal, mini, maxi, 0, 255);
	//error handling
}
